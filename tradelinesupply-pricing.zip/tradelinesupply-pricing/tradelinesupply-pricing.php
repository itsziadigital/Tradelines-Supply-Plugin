<?php
/**
 * Plugin Name: TradelineSupply Pricing Table
 * Description: Displays the pricing list from TradelineSupply.com using the [tradelinesupply_table] shortcode.
 * Version: 1.0
 * Author: Zia
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// 1. Add Settings Menu
function tsp_add_admin_menu() {
    add_options_page('Tradeline Settings', 'Tradeline API', 'manage_options', 'tradeline-pricing', 'tsp_options_page');
}
add_action('admin_menu', 'tsp_add_admin_menu');

function tsp_settings_init() {
    register_setting('tspPlugin', 'tsp_consumer_key');
    register_setting('tspPlugin', 'tsp_consumer_secret');
}
add_action('admin_init', 'tsp_settings_init');

function tsp_options_page() {
    ?>
    <div class="wrap">
        <h2>TradelineSupply API Settings</h2>
        <form action="options.php" method="post">
            <?php settings_fields('tspPlugin'); ?>
            <?php do_settings_sections('tspPlugin'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Consumer Key</th>
                    <td><input type="text" name="tsp_consumer_key" value="<?php echo esc_attr(get_option('tsp_consumer_key')); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th scope="row">Consumer Secret</th>
                    <td><input type="text" name="tsp_consumer_secret" value="<?php echo esc_attr(get_option('tsp_consumer_secret')); ?>" class="regular-text"></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// 2. Helper Functions (Renamed to avoid conflicts)
function tsp_join_with_equals_sign($params, $query_params = array(), $key = '') {
    foreach ($params as $param_key => $param_value) {
        if ($key) {
            $param_key = $key . '%5B' . $param_key . '%5D';
        }
        if (is_array($param_value)) {
            $query_params = tsp_join_with_equals_sign($param_value, $query_params, $param_key);
        } else {
            $string = $param_key . '=' . $param_value;
            $query_params[] = tsp_urlencode($string);
        }
    }
    return $query_params;
}

function tsp_urlencode($value) {
    if (is_array($value)) {
        return array_map('tsp_urlencode', $value);
    }
    return str_replace(array('+', '%7E'), array(' ', '~'), rawurlencode($value));
}

// 3. Shortcode Logic
function tsp_shortcode_function() {
    // Enqueue Assets
    wp_enqueue_style('bootstrap-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css');
    wp_enqueue_script('stupidtable-js', plugin_dir_url(__FILE__) . 'assets/stupidtable.js', array('jquery'), '1.0', true);
    wp_enqueue_style('tsp-custom-style', plugin_dir_url(__FILE__) . 'assets/style.css');

    // Inline script to init table
    wp_add_inline_script('stupidtable-js', 'jQuery(document).ready(function($){ $("table.tsp-table").stupidtable(); });');

    // API Logic
    $consumer_key = get_option('tsp_consumer_key');
    $consumer_secret = get_option('tsp_consumer_secret');
    $url = 'https://tradelinesupply.com/wp-json/wc/v3/pricing';

    if (empty($consumer_key) || empty($consumer_secret)) {
        return '<div class="alert alert-danger">Please configure API Keys in Settings > Tradeline API</div>';
    }

    $time = time();
    $params = [
        'oauth_consumer_key' => $consumer_key,
        'oauth_nonce' => $time,
        'oauth_signature_method' => 'HMAC-SHA1',
        'oauth_timestamp' => $time,
    ];
    
    $query = [];
    foreach ($params as $key => $value) {
        $query[] = $key . '=' . $value;
    }
    
    $base_request_uri = rawurlencode($url);
    $query_string = implode('%26', tsp_join_with_equals_sign($params));
    $string_to_sign = 'GET&' . $base_request_uri . '&' . $query_string;
    $hash_algorithm = 'sha1'; 
    $secret = $consumer_secret . '&';
    $signature = base64_encode(hash_hmac($hash_algorithm, $string_to_sign, $secret, true));

    $final_url = $url . "?" . implode('&', $query) . "&oauth_signature=" . $signature;

    // Use WordPress native HTTP request instead of raw cURL for better compatibility
    $response = wp_remote_get($final_url, array(
        'timeout' => 30,
        'headers' => array("cache-control" => "no-cache")
    ));

    if (is_wp_error($response)) {
        return "Error: " . $response->get_error_message();
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, JSON_OBJECT_AS_ARRAY);

    if (empty($data) || !is_array($data)) {
        return "No data received or invalid API response.";
    }

    // Output Buffer
    ob_start();
    ?>
    <div class="tsp-container">
        <table class="table tsp-table">
            <thead>
                <tr>
                    <th data-sort="int"></th>
                    <th data-sort="string">Bank Name</th>
                    <th data-sort="float" data-sort-onload="false">Card ID</th>
                    <th data-sort="float" data-sort-onload="false">Credit Limit</th>
                    <th data-sort="float" data-sort-onload="false">Date Opened</th>
                    <th data-sort="float" data-sort-onload="false">Purchase By Date</th>
                    <th data-sort="float" data-sort-onload="false">Reporting Date</th>
                    <th data-sort="float" data-sort-onload="false">Stock</th>
                    <th data-sort="float" data-sort-onload="yes">Price</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($data as $line): ?>
                <tr>
                    <td><img src="<?php echo esc_url($line['image']); ?>" style="width: 50px"/></td>
                    <td><?php echo esc_html($line['bank_name']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['card_id']);?>"><?php echo esc_html($line['card_id']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['credit_limit_original']); ?>"><?php echo esc_html($line['credit_limit']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['date_opened_original']); ?>"><?php echo esc_html($line['date_opened']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['purchase_deadline_original']); ?>"><?php echo esc_html($line['purchase_deadline']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['reporting_period_original']); ?>"><?php echo esc_html($line['reporting_period']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['stock']); ?>"><?php echo esc_html($line['stock']); ?></td>
                    <td data-sort-value="<?php echo esc_attr($line['price']); ?>">$<?php echo esc_html($line['price']); ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('tradelinesupply_table', 'tsp_shortcode_function');